sap.ui.define([
	"Z/SplitApp/test/unit/controller/App.controller"
], function () {
	"use strict";
});