/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"Z/SplitApp/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});